
<?php $__env->startSection('content'); ?>



<section class="pricing-plans" id="pricing-plans">
    <div class="container">
        <div class="row ">
            <div class="col-lg-6 m-auto text-center header_texts pt-10">
                <h3 style="color: #fff; font-size:38px; font-width:600;">Order Now</h3>
            </div>
        </div>
    </div>
<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="pricing-card basic">
    <div class="heading">
        <h4 style=" color:#00aeef"><?php echo e($plan->plan_name); ?></h4>
        <p><?php echo e($plan->plan_description); ?></p>
    </div>
    <p class="price">
        $<?php echo e($plan->plan_price); ?>

        <sub>/month</sub>
    </p>
<?php $__currentLoopData = $plan->planItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<ul class="features">
    <li>
        <i class="fa-solid fa-check"></i>
        <?php echo e($p_item->plan_item_name); ?>

    </li>

</ul>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(route('plan_get', $plan->id)); ?>" class="cta-btn">SELECT</a>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</section>

<section id="single-plans">
    <div class="container">
        <div class="row">
            <div class="col-lg-4 m-auto text-center header_texts">
                <h2>Single Plan</h2>
            </div>
        </div>
        

        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="row v_l_middle mt_mar">
            <div class="col-lg-4 s_p_im">
                <div class="s_p_main d-flex">
                    <div class="s_p_image">
                        <img src="<?php echo e(asset($service->service_image)); ?>" alt="service_image" class="img-fluid w-100">
                    </div>
                    <div class="s_p_details">
                        <h3><?php echo e($service->service_name); ?> <span><i class="fa-brands fa-servicestack"></i></span></h3>
                        <p><?php echo e($service->service_description); ?></p>
                    </div>
                </div>
            </div>
            <?php $__currentLoopData = $service->ServicePackItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ss_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-2 s_p_p text-center">
                <a href="<?php echo e(route('order', $ss_item->id)); ?>">
                    <div class="s_p_pricing_main">
                        <div class="s_p_content">
                            <h3><?php echo e($ss_item->package_name); ?></h3>
                        </div>
                        <div class="s_p_price">
                            <p>@start from</p>
                            <h3>&#36 <?php echo e($ss_item->package_price); ?> </h3>
                            <p>Per Image</p>
                        </div>
                    </div>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-2 s_p_p text-center">
                <a href="#">
                    <div class="s_p_pricing_main">
                        <div class="s_p_content">
                            <h3>MUlti-Order</h3>
                        </div>
                        <div class="s_p_price">
                            <p>@start from</p>
                            <h3>Talk To Us </h3>
                            <p>Any Quantity</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</section>

<section id="trailNowForm">
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto text-center header_texts">
                <h2>Trail <span style="color: #00aeef;">Now</span></h2>
            </div>
        </div>
        <div class="row text-center pt-5">
            <div class="col-md-6 mx-auto ">
                <form action="<?php echo e(route('freetrail.submit')); ?>" method="post" enctype="multipart/form-data" class="text-center">
                    <?php echo csrf_field(); ?>
                    <div class="form-group text-center">

                        <input type="text" class="form-control" name="name" id="name" placeholder="Enter name">
                    </div>
                    <div class="form-group">

                        <input type="email" class="form-control" name="email" id="email" placeholder="Enter email">
                    </div>
                    <div class="form-group">

                        <input type="tel" class="form-control" name="phone" id="phone" placeholder="Enter phone number">
                    </div>
                    <div class="form-group">

                        <input type="file" class="form-control" name="file" id="phone" placeholder="Choose Your File">
                    </div>

                    <button type="submit" class="btn btn-primary trail_btn">Submit</button>


                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendmaster', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Rakib-Pro.bd\Desktop\fiverr all work file\inventcreationit\resources\views/frontend/index.blade.php ENDPATH**/ ?>
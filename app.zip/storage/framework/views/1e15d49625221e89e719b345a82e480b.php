<section class="space-y-6">
    

    

</section>
<?php /**PATH C:\Users\Rakib-Pro.bd\Desktop\fiverr all work file\inventcreationit\resources\views/profile/partials/delete-user-form.blade.php ENDPATH**/ ?>